package com.fsb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FsbApplicationTests {

	@Test
	void contextLoads() {
	}

}
