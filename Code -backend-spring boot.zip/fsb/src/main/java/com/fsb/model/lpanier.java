package com.fsb.model;

import java.util.Date;
import com.fsb.model.*;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
@Entity
@Table(name="lpanier")
public class lpanier {

  
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "id_list", unique = true, nullable = false, insertable=false, updatable=false)
    private int id_list;
	

	private int qte;
	private double  total;
	private String TicketType;
	private String libelle;
	private double price;

	@ManyToOne(fetch=FetchType.LAZY, cascade = CascadeType.ALL)
	@JsonBackReference("panier")
	@JoinColumn(name="panier_id", referencedColumnName="panier_id")
	private panier panier;
	
	
	
	
	
	
	
	
	
	@ManyToOne(fetch=FetchType.LAZY, cascade = CascadeType.ALL)
	@JsonBackReference("utilisateurs")
	@JoinColumn(name="user_id", referencedColumnName="id")
      private utilisateurs user;

	public lpanier(int id_list, int numero, int  qte, int total, String libelle, int price,
			com.fsb.model.panier panier, com.fsb.model.utilisateurs user) {
		super();
		this.id_list = id_list;
		
		this.qte = qte;
		this.total = total;
		this.libelle = libelle;
		this.price = price;
		this.panier = panier;
	this.user = user;
	}

	public utilisateurs getUser() {
		return user;
	}

	public void setUser(utilisateurs user) {
		this.user = user;
	}

	
/*	public void setuser(utilisateurs utilisateurs) {
		//this.user=utilisateurs;
		
	}  */

	public lpanier(int id_list, int numero, int qte, int total, String libelle, int price,panier panier) {
		super();
		this.id_list = id_list;
	
		this.qte = qte;
		this.total = total;
		this.libelle = libelle;
		this.price = price;
		this.panier = panier;
	}

	public int getQte() {
		return qte;
	}
	public void setQte(int qte) {
		this.qte = qte;
	}
	
	public String getLibelle() {
		return libelle;
	}
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}
	public panier getPanier() {
		return panier;
	}
	public void setPanier(panier panier) {
		this.panier = panier;
	}
	
	
	
	public int getId_list() {
		return id_list;
	}
	public void setId_list(int id_list) {
		this.id_list = id_list;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}


	public String getTicketType() {
		return TicketType;
	}

	public void setTicketType(String ticketType) {
		TicketType = ticketType;
	}

	public lpanier(int id_list, int qte, int total, String ticketType, String libelle, double price,
			com.fsb.model.panier panier, utilisateurs user) {
		super();
		this.id_list = id_list;
		this.qte = qte;
		this.total = total;
		TicketType = ticketType;
		this.libelle = libelle;
		this.price = price;
		this.panier = panier;
		this.user = user;
	}

	public lpanier() {
		super();
		// TODO Auto-generated constructor stub
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}

	

	}














