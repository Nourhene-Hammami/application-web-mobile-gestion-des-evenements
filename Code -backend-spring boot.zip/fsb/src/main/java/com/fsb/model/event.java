package com.fsb.model;

import java.io.File;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name="event")

public class event {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name=" id")
	private int id;
	@Column(name="name",nullable=false)
	private String name;
	private String lieu;
	private Date date;
	private String desp;
	
	private double priceForStudent;

	//@JsonProperty("priceForNoStudent")
	private double priceForNoStudent;
	private int stoke;
	private String city;
	private String filenameimg;
	private String  organizateur;
	

	
	

	public event(int id, String name, String lieu, Date date, String desp, int price, int qte, String city,
			String filenameimg, int total) {
		super();
		this.id = id;
		this.name = name;
		this.lieu = lieu;
		this.date = date;
		this.desp = desp;
		this.priceForStudent = price;
	//	this.qte = qte;
		this.city = city;
		this.filenameimg = filenameimg;
		//this.total = total;
	}
	public String getOrganizateur() {
		return organizateur;
	}
	public void setOrganizateur(String organizateur) {
		this.organizateur = organizateur;
	}
	public event(int id, String name, String lieu, Date date, String desp, double priceForStudent, int stoke, String city,
			String filenameimg, String organizateur) {
		super();
		this.id = id;
		this.name = name;
		this.lieu = lieu;
		this.date = date;
		this.desp = desp;
		this.priceForStudent = priceForStudent;
		this.stoke = stoke;
		this.city = city;
		this.filenameimg = filenameimg;
		this.organizateur = organizateur;
	}
	
	
	public event(int id, String name, String lieu, Date date, String desp, double priceForStudent,
			double priceForNoStudent, int stoke, String city, String filenameimg, String organizateur) {
		super();
		this.id = id;
		this.name = name;
		this.lieu = lieu;
		this.date = date;
		this.desp = desp;
		this.priceForStudent = priceForStudent;
		this.priceForNoStudent = priceForNoStudent;
		this.stoke = stoke;
		this.city = city;
		this.filenameimg = filenameimg;
		this.organizateur = organizateur;
	}
	public double getPriceForNoStudent() {
		return priceForNoStudent;
	}
	public void setPriceForNoStudent(double priceForNoStudent) {
		this.priceForNoStudent = priceForNoStudent;
	}
	public event(int id, String name, String lieu, Date date, String desp, int priceForStudent, int stoke, String city,
			String filenameimg) {
		super();
		this.id = id;
		this.name = name;
		this.lieu = lieu;
		this.date = date;
		this.desp = desp;
		this.priceForStudent = priceForStudent;
		this.stoke = stoke;
		this.city = city;
		this.filenameimg = filenameimg;
	}
	public String getFilenameimg() {
		return filenameimg;
	}
	public void setFilenameimg(String filenameimg) {
		this.filenameimg = filenameimg;
	}
	

	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

	public String getDesp() {
		return desp;
	}
	
	

	public void setDesp(String desp) {
		this.desp = desp;
	}

	public int getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLieu() {
		return lieu;
	}
	public void setLieu(String lieu) {
		this.lieu = lieu;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public void setId(int id) {
		this.id=id;
	}
	public double getPriceForStudent() {
		return priceForStudent;
	}
	public void setPriceForStudent(double price) {
		this.priceForStudent = price;
	}
	
	
	
	
	public int getStoke() {
		return stoke;
	}
	public void setStoke(int stoke) {
		this.stoke = stoke;
	}
	public event() {
		super();
	}
	public event(int id, String name, String lieu, Date date, String desp, int price, int stoke, String city)
			 {
		super();
		this.id = id;
		this.name = name;
		this.lieu = lieu;
		this.date = date;
		this.desp = desp;
		this.priceForStudent = price;
		this.stoke = stoke;
		this.city = city;
		
	}
	
	
}
