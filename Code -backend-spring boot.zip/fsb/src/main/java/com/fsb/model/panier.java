package com.fsb.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
@Entity
@Table(name="panier")
public class panier {
  
  
	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name=" panier_id")
	private long panier_id;
	
	private String nom;
	private String adresse;
	private String ville;
	private String codep;
	private int tel;
	
	
	


	@JsonManagedReference
	@JsonIgnore
	
	@OneToMany(mappedBy="panier",fetch=FetchType.EAGER)

	private List<lpanier> lpaniers = new ArrayList<>();
	
	   
    
    public panier(long panier_id, int annee, int numero, Date date_mvt, String nom, String adresse, String ville,
			String codep, int tel, String numcarte) {
		super();
		panier_id = panier_id;
		
		this.nom = nom;
		this.adresse = adresse;
		this.ville = ville;
		this.codep = codep;
		this.tel = tel;
	}
	public panier(int annee, int numero, Date date_mvt, String nom, String adresse, String ville, String codep,
			int tel, double totht, double tottva, double totttc, String numcarte, List<lpanier> lpaniers) {
		super();
	
		this.nom = nom;
		this.adresse = adresse;
		this.ville = ville;
		this.codep = codep;
		this.tel = tel;
		
		
		this.lpaniers = lpaniers;
	}
	public List<lpanier> getLpaniers() {
		return lpaniers;
	}
	public void setLpaniers(List<lpanier> lpaniers) {
		this.lpaniers = lpaniers;
	}
	
	public long getpanier_id() {
		return panier_id;
	}
	public void setpanier_id(long panier_id) {
		panier_id = panier_id;
	}


	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public String getVille() {
		return ville;
	}
	public void setVille(String ville) {
		this.ville = ville;
	}
	public String getCodep() {
		return codep;
	}
	public void setCodep(String codep) {
		this.codep = codep;
	}
	public int getTel() {
		return tel;
	}
	public void setTel(int tel) {
		this.tel = tel;
	}

	

	@Override
	public String toString() {
		return "panier [panier_id=" + panier_id + ", nom=" + nom + ", adresse=" + adresse + ", ville=" + ville
				+ ", codep=" + codep + ", tel=" + tel + ", lpaniers=" + lpaniers + "]";
	}
	public panier() {
		super();
	}
	public panier(long panier_id, int annee, int numero, Date date_mvt, String nom, String adresse, String ville,
			String codep, int tel, String numcarte, List<lpanier> lpaniers) {
		super();
		panier_id = panier_id;
		
		this.nom = nom;
		this.adresse = adresse;
		this.ville = ville;
		this.codep = codep;
		this.tel = tel;
		this.lpaniers = lpaniers;
	}
	public panier(long panier_id2) {
		this.panier_id=panier_id2;
	}

	
	
	
	
	
	
	
	



}