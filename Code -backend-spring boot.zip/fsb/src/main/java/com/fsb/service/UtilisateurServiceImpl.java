package com.fsb.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fsb.dbutil.DBUtil;
import com.fsb.model.utilisateurs;
import com.fsb.repository.RegistrationRepository;
import com.fsb.repository.UtilisateurRepo;

@Service
public class UtilisateurServiceImpl implements UtilisateurRepo  {

    int flag=0;
    Connection connection  ;
	
	public UtilisateurServiceImpl() throws SQLException {
		connection=DBUtil.getConnection();
	}
	@Autowired
	private RegistrationRepository repo;
	
	
	
	 public List<utilisateurs> getAllUsers() {
	        return repo.findAll();
	    }
	 
	  public Optional<utilisateurs> getUserById(int id) {
	     //   return repo.findById(id);
		  return repo.findById(id);
	    }
	 
	  public utilisateurs addUser(utilisateurs user) {
	        return repo.save(user);
	    }
	 
	  
	  public void deleteUser(int  id) {
	        repo.deleteById(id);
	    }
	  
	  public utilisateurs  updateUser(int id, utilisateurs user) {
		  utilisateurs existingUser = repo.findById(id).orElse(null);
	        if (existingUser != null) {
	            existingUser.setName(user.getName());
	            existingUser.setMail(user.getMail());
	            existingUser.setPassword(user.getPassword());
	            existingUser.setRole(user.getRole());
	            return repo.save(existingUser);
	        }
	        return null;
	    }
	  
	  
	public utilisateurs saveUser(utilisateurs user) {
		user.setRole("user");
		return repo.save(user);
	}
	
	
	public utilisateurs fetchUserByMail(String mail) {
		 return repo.findByMail(mail);
	}


	
	@Override
	public int loginValidation(String mail, String password, String role) {
	    try {
	        PreparedStatement statement = connection.prepareStatement("SELECT * FROM UTILISATEURS WHERE mail = ?");
	        statement.setString(1, mail);
	        ResultSet rs = statement.executeQuery();

	        while (rs.next()) {
	            if (rs.getString(2).equals(mail) && rs.getString(4).equals(password)) {
	                System.out.println("Valid mail and password");
	                flag = 1;
	                role = rs.getString("role"); // retrieve the role of the user from the result set
	            } else {
	                System.out.println("Invalid mail or password!!!!!");
	                flag = 0;
	            }
	        }

	        if (flag == 1 && role.equals("user")) {
	            System.out.println("You are a normal user");
	        } else if (flag == 1 && role.equals("admin")) {
	            System.out.println("You are an admin ");
	        } 
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return flag;
	}

}










