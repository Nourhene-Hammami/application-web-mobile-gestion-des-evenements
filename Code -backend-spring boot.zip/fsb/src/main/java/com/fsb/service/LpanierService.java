package com.fsb.service;

import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.fsb.model.event;
import com.fsb.model.lpanier;
import com.fsb.model.panier;
import com.fsb.model.utilisateurs;
import com.fsb.repository.LpanierRepository;
import com.fsb.repository.PanierRepository;
import com.fsb.repository.RegistrationRepository;

@Service
public class LpanierService {



	@Autowired
    private PanierRepository panierRepository;
 
    @Autowired
    private LpanierRepository lpanierRepository;
    
    @Autowired
    private   RegistrationRepository repo; 
 
   public lpanier save(lpanier lpanier,long panierId ,int userId ) {
        // Créer un nouvel objet lpanier



	   
	   // Retrieve the existing panier object from the database using panierId
	    
	 //  panier event = new panier();
	  //  // event.setPanierId(panierId);
	      
	      
        lpanier lpanier1 = new lpanier();
       
        lpanier1.setLibelle(lpanier.getLibelle());
        lpanier1.setPrice(lpanier.getPrice());
        lpanier1.setQte(lpanier.getQte());
        lpanier1.setTotal(lpanier.getTotal());
        lpanier1.setTicketType(lpanier.getTicketType());
        
       
        Optional< utilisateurs> u = repo.findById(userId);
        if (u.isPresent()) {
     //   lpanier1.setUser(u.get());
        lpanier1.setUser(u.get());
        } else {
            throw new RuntimeException("user not found");
        }
        
        
        
        
        // Retrieve the existing panier object from the database using panierId
        Optional<panier> panier = panierRepository.findById(panierId);
        if (panier.isPresent()) {
            lpanier1.setPanier(panier.get());

            // Save the lpanier object to the database
          
        } else {
            throw new RuntimeException("Panier not found");
        }
   //     return lpanierRepository.save(lpanier1);   
        return lpanierRepository.save(lpanier1);
   }
   
   
   

	  public Optional<lpanier> getUserById(int id) {
	     //   return repo.findById(id);
		  return repo.findUserById(id);
	    }
   
   
   
   
   
   
   
   
   
   public Optional<lpanier> findUserById(int user_id ){
		 return repo.findUserById(user_id);
	 }
	
}
      
        
    /* panier panier = panierRepository.findById(panierId)
          
    		 .orElseThrow(() -> new RuntimeException("Panier not found")); // Throw an exception if panier is not found
     
     lpanier1.setPanier(panier);*/
    // System.out.println("panier id "+lpanier);
     // Enregistrer l'objet lpanier dans la table lpanier
  //   lpanier1.setPanier(lpanier.getPanier()); 
     //   lpanier1.setPanier(new panier(panierId));
    
         

         // Récupérer l'objet panier correspondant à l'ID de panier (panier_id) et l'associer à l'objet lpanier
        
       
      /* Optional<panier> panierOpt = panierRepository.findById(lpanier.getPanier()());

         panier panier =new panier ();
         panier.(lpanier.getPanier());
         lpanier1.setPanier(panier);*/
     // Retrieve the panier object from the database
     //   Optional<panier> panierOpt = panierRepository.findById(lpanier.getPanier().getPanierId()); 
      //  System.out.println("panier id "+lpanier.getPanier().getPanierId());
      //  panier panier = panierOpt.orElseThrow(() -> new RuntimeException("Panier not found"));

        // Set the properties of the lpanier object
        //lpanier.setPanier(panier);
       
       
       

 

   
   
   
   
   
   
   

