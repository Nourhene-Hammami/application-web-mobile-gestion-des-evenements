package com.fsb.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.Entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.multipart.MultipartFile;

import com.fsb.model.event;
import com.fsb.repository.CrudEventRepo;

@Service
public class CrudEventService {
	
	
	@Autowired
	private CrudEventRepo repo;
	
	
	public List<event> fetchEventList(){
		return repo.findAll();
	}
	
	
	/*public event saveEventToDB(event event) {
		return repo.save(event);
	}*/
	
	public event saveEventToDB(event event) {
		event e =new event();
		e.setCity(event.getCity());
		e.setDate(event.getDate());
		e.setDesp(event.getDesp());
		e.setFilenameimg(event.getFilenameimg());
  	    e.setStoke(event.getStoke());
		e.setId(event.getId());
		e.setLieu(event.getLieu());
		e.setPriceForStudent(event.getPriceForStudent());
		e.setPriceForNoStudent(event.getPriceForNoStudent());
		e.setName(event.getName());
		e.setOrganizateur(event.getOrganizateur()); 
		return repo.save(e);	
	}
	
	
	
	public Optional<event> fetchEventById(int id) {
		return repo.findById(id);
	}
	
	
	public String  deleteEventById(int id) {
		String result;
		try {repo.deleteById(id);
		result="event delete succesfully";
		}catch(Exception e){   
			result="event delete failed";         } 
		
		return result;
	}
	
	
	
	
	
	
	

}
