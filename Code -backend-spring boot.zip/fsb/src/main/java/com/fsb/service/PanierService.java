package com.fsb.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.*;

import com.fsb.model.lpanier;
import com.fsb.model.panier;
import com.fsb.repository.LpanierRepository;
import com.fsb.repository.PanierRepository;
@Service
@Transactional
public class PanierService {

	@Autowired
	PanierRepository repository;
	@Autowired
	LpanierRepository lprepository;
	

/*	public List<panier> getALL() {
		System.out.println("get all paniers.......");
		return repository.findAll(Sort.by("numero").ascending());
	}
*/
	
	 public Optional<panier> findById(long PanierId){
		 return repository.findById(PanierId);
	 }
	
	 public long save(panier panier) {
		 List<lpanier> lpaniers = panier.getLpaniers();
		 for(lpanier lp:lpaniers)
		 {
			 //lp.setNumero(panier.getNumero());
			 lprepository.save(lp);
		 }
		
		
				 return repository.save(panier).getpanier_id();
		 
		 
		 
	 }

	
	 public void update(String code ,panier panier ) {
		
		 }
		 
		 
		 public List<panier> findByNom(String nom) {
				return repository.findAllByNom(nom) ;	
				
			}
		 
		 public void delete (long id) {
			 Optional<panier> cat=repository.findById(id);
			 cat.ifPresent(repository::delete);
		 }
		 
		 
		 
		 
		 
		 
	 }
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	
	
	
	
	


