package com.fsb.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.fsb.model.lpanier;
import com.fsb.model.panier;
import com.fsb.model.utilisateurs;
@Repository
@EnableJpaRepositories
public interface RegistrationRepository extends JpaRepository<utilisateurs,Integer> {
	public utilisateurs findByMail(String mail);
	Optional<utilisateurs>  findById( int userId) ;
	 Optional<lpanier>  findUserById( int user_id) ;
}
