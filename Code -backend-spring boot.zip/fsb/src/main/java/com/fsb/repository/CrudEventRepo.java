
package com.fsb.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fsb.model.event;

public interface CrudEventRepo extends JpaRepository<event,Integer>{
	
	
	
	
}
