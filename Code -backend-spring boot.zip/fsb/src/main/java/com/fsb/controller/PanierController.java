package com.fsb.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fsb.model.panier;
import com.fsb.service.PanierService;
@CrossOrigin("*")
@RestController
public class PanierController {
	@Autowired 
	private PanierService panierService;
	
/*	@GetMapping("/paniers")
	public List<  panier  >list(){
		System.out.println("get all paniers.......");
		return panierService.getALL() ;	
	}*/
	
	@GetMapping("/paniers/{id}")
	public ResponseEntity<panier>post( @PathVariable long id){
	Optional<panier> cat= panierService.findById(id);
	return cat.map(ResponseEntity::ok)
			.orElseGet(() -> ResponseEntity.notFound()
			                  .build());
	}
	
	@PostMapping("/paniers")
	public long save(@RequestBody panier panier) {
		return panierService.save(panier);
	}
	
	
	@PutMapping("/paniers/{code}")
	public void update (@PathVariable long id, @RequestBody panier panier) {
	
		
		
	}
		
		
		
		
		@DeleteMapping("/paniers/{id}")
		public void delete(@PathVariable long id) {
			panierService.delete(id);
		
		}
		
		
		
		
		
	}


	
	
	
	
	
	
	
	

