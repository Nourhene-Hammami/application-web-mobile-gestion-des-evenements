package com.fsb.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fsb.dbutil.DBUtil;
import com.fsb.model.utilisateurs;

import com.fsb.service.UtilisateurServiceImpl;
import com.mysql.jdbc.PreparedStatement;

@RestController

@CrossOrigin("*")
public class UtilisateurController {
	
	
	 Connection connection  ;

		public UtilisateurController() throws SQLException {
			connection=DBUtil.getConnection();
		}
	@Autowired
	private UtilisateurServiceImpl utilisateurservice;
	
	
	
	
	@GetMapping("/utilisateur/{mail}")
	public ResponseEntity<utilisateurs> getUserByMail(@PathVariable String mail) {
	    utilisateurs user = utilisateurservice.fetchUserByMail(mail);
	    if (user != null) {
	        return new ResponseEntity<>(user, HttpStatus.OK);
	    } else {
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }
	}


	 @GetMapping("/getusers")
	    public List<utilisateurs> getAllUsers() {
	        return utilisateurservice.getAllUsers();
	    }
	    
	    
	    @GetMapping("/getuser/{id}")
	    public Optional<utilisateurs> getUserById(@PathVariable int id) {
	        return  utilisateurservice.getUserById(id);
	    }
	    
	    
	    
	    @PostMapping("/adduser")
	    public utilisateurs  addUser(@RequestBody utilisateurs user) {
	        return utilisateurservice.addUser(user);
	    }

	    @PutMapping("/updateuser/{id}")
	    public utilisateurs updateUser(@PathVariable int id, @RequestBody utilisateurs user) {
	        return utilisateurservice.updateUser(id, user);
	    }

	    @DeleteMapping("/deleteuser/{id}")
	    public void deleteUser(@PathVariable int id) {
	    	utilisateurservice.deleteUser(id);
	    }

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@GetMapping("utilisateur/{mail}/{password}")
	public int UserLogin(@PathVariable("mail") String mail1, @PathVariable("password") String password1) {
	    String role = ""; // initialize the 'role' parameter
	    int flag = utilisateurservice.loginValidation(mail1, password1, role);
	    if (flag == 0) {
	        System.out.println("Authentification non valide");
	        return 0;

	    }

	    System.out.println("Authentification valide");
	    return flag;
	}
	
	
	
	
	
	
	
	
	
	@GetMapping("/utilisateur/role/{mail}")
	public String getUserRole(@PathVariable("mail") String mail) {
	  try {
	    //PreparedStatement statement = connection.prepareStatement("SELECT role FROM UTILISATEURS WHERE mail = ?");
		  java.sql.PreparedStatement statement = connection.prepareStatement("SELECT role FROM UTILISATEURS WHERE mail = ?");
	    statement.setString(1, mail);
	    ResultSet rs = statement.executeQuery();
	    if (rs.next()) {
	      return rs.getString("role");
	    } else {
	      return "unknown";
	    }
	  } catch (SQLException e) {
	    e.printStackTrace();
	    return "unknown";
	  }
	 
	}


	
	/*@GetMapping("utilisateur/{mail}/{password}")
	public int UserLogin(@PathVariable("mail") String mail1,@PathVariable("password") String password1)  {
	
		int flag=utilisateurservice.loginValidation(mail1, password1);
		if(flag  == 0) {
			System.out.println(" authentification non valide");
		return 0;
		
		}
		
		System.out.println(" authentification  valide");
		return flag;
		} */
		
		
	
	@PostMapping(value="/registeruser")
	public utilisateurs  registerUser(@RequestBody utilisateurs user) throws Exception  {
		String tempMail=user.getMail();
		if(tempMail !=null && !"".equals(tempMail)) {
			utilisateurs userObj = utilisateurservice.fetchUserByMail(tempMail);
			if(userObj !=null) {
				throw new Exception ("user with    "    +tempMail+   "   is already exist ..repeat with other mail") ;
				
			}
		}
		utilisateurs userObj =null;
		userObj=utilisateurservice.saveUser(user);
		return userObj;
		
	}
	
	
	
	
	
	
	
	
	
	}

