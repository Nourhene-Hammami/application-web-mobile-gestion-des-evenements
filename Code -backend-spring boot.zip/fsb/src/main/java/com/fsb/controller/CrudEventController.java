package com.fsb.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.xml.ws.Response;

import org.apache.commons.io.FilenameUtils;
import org.apache.tomcat.util.http.fileupload.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.fsb.model.event;
import com.fsb.service.CrudEventService;



@RestController
public class CrudEventController {
	
	@Autowired
	private CrudEventService  service;
	
	 @Autowired 
	 private ServletContext context;
	
	
	@GetMapping("/geteventlist")
	@CrossOrigin(origins="http://localhost:4200")
	public List<event> fetchEventList(){

	
		List<event> events=new ArrayList<event>();
		
		events=service.fetchEventList();
		
		return events;
	}
	 
	
	
	@PostMapping(value={"/addevent"} )
	@CrossOrigin(origins="http://localhost:4200")
	public event createEvent(@RequestParam("event") String event,@RequestParam("file") MultipartFile[] files) 
	throws JsonParseException,JsonMappingException,Exception{
		System.out.print("ok...");
		event e=new ObjectMapper().readValue(event, event.class);
		
		for (MultipartFile f : files) {
		String filenameimg=f.getOriginalFilename();

		 String newFilename = FilenameUtils.getBaseName(filenameimg);
		File serveFile= new File(context.getRealPath("/Images/" +File.separator+newFilename));
		try {
			System.out.println("images");
	
			Files.write(serveFile.toPath(),f.getBytes());
}catch(Exception a) {a.printStackTrace();}
e.setFilenameimg(newFilename);
}
return service.saveEventToDB(e);} 

	
	

	 @GetMapping("/imageevents/{id}")
	 @CrossOrigin(origins="http://localhost:4200")
	 public byte[] getPhoto(@PathVariable int id)throws Exception {
		 event e= service.fetchEventById(id).get();
		 return Files.readAllBytes(Paths.get(context.getRealPath("/Images/")  +e.getFilenameimg()        ));
		 
	 }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
/*	
@PostMapping(value={"/addevent"},consumes={MediaType.MULTIPART_FORM_DATA_VALUE})
	@CrossOrigin(origins="http://localhost:4200")
	public event saveEvent(@RequestPart("event") event event,@RequestPart("imageFile")MultipartFile[] file) {
		try {
			Set<ImageModel> images=uploadImage(file);
			event.setEventImages(images);
         return service.saveEventToDB(event);
		}catch(Exception e ) {
			System.out.println(e.getMessage());
			return null;
		}
	}
	 
	public Set<ImageModel> uploadImage(MultipartFile[] multipartFiles) throws IOException {
		Set<ImageModel> imageModels=new HashSet<>();
		for(MultipartFile file  : multipartFiles) {
			ImageModel imageModel=new ImageModel (
	    file.getOriginalFilename(),
					file.getContentType(),
	 	            file.getBytes()
);imageModels.add(imageModel)	;	
		}
		return imageModels;
	}*/
	
	
	
@GetMapping("/geteventbyid/{id}")
	@CrossOrigin(origins="http://localhost:4200")
	public event fetchEventById(@PathVariable int id){
	System.out.println("get event by id ");
	return service.fetchEventById(id).get();
	}
	 
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@DeleteMapping("/deleteventbyid/{id}")
	@CrossOrigin(origins="http://localhost:4200")
	public String deleteEventById(@PathVariable int id){
		return service.deleteEventById(id);
	}
	
	

	
	
	
	

}
