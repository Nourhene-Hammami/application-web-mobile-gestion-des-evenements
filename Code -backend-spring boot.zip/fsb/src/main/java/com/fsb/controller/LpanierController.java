package com.fsb.controller;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fsb.model.lpanier;
import com.fsb.model.panier;
import com.fsb.model.utilisateurs;
import com.fsb.repository.RegistrationRepository;
import com.fsb.service.LpanierService;
import com.fsb.service.PanierService;
@CrossOrigin("*")
@RestController
public class LpanierController {
    
    @Autowired
    private LpanierService lpanierService;
    @Autowired
	private RegistrationRepository repo;
    
   /* @PostMapping("/lpanier/{id}")
    public lpanier saveLpanier(@RequestBody lpanier lpanier) {
        return lpanierService.save(lpanier);
    }
    */
    @PostMapping("/lpanier/{panierId}/{userId}")
    public lpanier saveLpanier(@RequestBody lpanier lpanier, @PathVariable long panierId, @PathVariable int userId) {
        // Set the panier_id property of the lpanier object
    	
       // lpanier.setPanier(new panier(panierId));
        return lpanierService.save(lpanier, panierId,userId);
    }

    
	
    
    
    
}



