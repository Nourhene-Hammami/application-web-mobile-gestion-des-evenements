package com.fsb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FsbApplication {

	public static void main(String[] args) {
		SpringApplication.run(FsbApplication.class, args);
		System.out.println("welcome to our PFE");
	}

}
